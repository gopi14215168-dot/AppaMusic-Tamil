# Appa Music — first Android MVP

A beginner-friendly native Android app starter for importing local audio files and playing them offline. Includes a Tamil-friendly Compose screen and a Media3 session service for background playback.

## Requirements
- Android Studio with JDK 17 (Android Studio's bundled JDK is fine)
- Internet once, to download Gradle dependencies
- Android phone and USB cable for installation/testing

## Open and run
1. Extract this ZIP to a folder such as `C:\Projects\AppaMusic`.
2. Open Android Studio → **Open** → choose the extracted `AppaMusic` folder (the one containing `settings.gradle.kts`).
3. Accept the Gradle sync/download prompts. If prompted, use JDK 17.
4. On your Android phone, enable Developer options and USB debugging. Connect by USB and accept the computer authorization prompt.
5. Select your phone in Android Studio's device list and press **Run ▶**.
6. In Appa Music, tap **பாடல்களைச் சேர்க்க / Import audio songs** and select audio files. Try a few MP3 files first.
7. Once imported, disconnect the network and test playback. The selected audio files remain accessible through Android's document picker permission.

## Notes
- The app does not include copyrighted music. Add audio files you own or are authorized to download/use.
- This is an initial MVP: category tiles are a visual starting point; category-specific filtering, persistent playlists/favourites, search, and sleep timer are future improvements.
- If Gradle sync fails, check Android Studio's Build output and verify JDK 17 plus internet access for the first dependency download.

## Bulk folder import update
- Tap **Folder Import** and select a folder in Android's system folder picker.
- The app recursively scans supported audio types (MP3, M4A, AAC, WAV, OGG, FLAC, OPUS) and shows a preview before importing.
- Select one category for the entire folder batch, then tap **Import all**.
- Duplicate checks skip an existing URI or a matching file name. This is a practical heuristic, not an audio-content fingerprint; same-named different songs may be treated as duplicates.
- A batch report shows added and skipped counts. **Undo last batch** removes the songs added in the most recent batch from the app library; it does not delete the original audio files.
- Use the folder icon beside an imported song to reassign its category.
- Categories are manually assigned per batch to avoid unreliable automatic classification. If a folder contains mixed artists, import smaller subfolders or reassign songs after import.
- Audio files remain in their original folders. The app stores document URIs and requires the selected folder provider to support persistent access.

This update has not been built or tested on a physical device in this environment. Please run Gradle Sync and Build in Android Studio; if an error appears, share the complete Build output.

## Custom categories and names update
- Tap **Manage Categories & Names** on the home screen.
- Use **Add category** to create categories such as `1985`, `Old favourites`, or `Temple songs`.
- Choose a name type (Music Director, Actor, Singer, Movie, Devotional Deity, or Year / Decade), type a name, and tap **Save name**. The app saves entries locally and makes them available in the folder-import and change-category menus.
- Custom entries persist on this phone using app preferences. Deleting a custom entry moves songs assigned to it to `Uncategorized`; it does not delete audio files.
- In this starter version, a name is represented as a selectable category label (for example `Singer: S. P. Balasubrahmanyam`). Full multi-field song metadata (separate artist/director/actor fields) and Room database migration are not implemented yet.

## Important limitations
- This source project was updated, but it has **not been built or tested on a physical Android device** in this environment. Run **Sync Project with Gradle Files** and then **Build > Make Project** in Android Studio.
- The folder picker keeps audio in the original folder and stores document URIs; the phone must continue to grant access to those files.
- Online music opens a web search for legitimate download options. It does not download songs automatically and does not bypass streaming-service restrictions.
