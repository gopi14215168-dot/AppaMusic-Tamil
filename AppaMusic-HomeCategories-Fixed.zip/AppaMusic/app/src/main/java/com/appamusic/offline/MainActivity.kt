package com.appamusic.offline

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.common.util.UnstableApi
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    @androidx.annotation.OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AppaMusicScreen() } }
}

data class Song(val uri: Uri, val title: String, val category: String = "Uncategorized")
data class PendingSong(val uri: Uri, val title: String)
private val songCategories = listOf("All Songs", "1980s", "1990s", "Devotional", "Ilaiyaraaja / இளையராஜா", "A. R. Rahman / ஏ.ஆர். ரஹ்மான்", "MS Viswanathan / எம்.எஸ்.வி.", "Rajinikanth / ரஜினி", "Kamal Haasan / கமல்", "MGR / எம்.ஜி.ஆர்.", "Sivaji Ganesan / சிவாஜி", "Murugan / முருகன்", "Amman / அம்மன்", "Shiva / சிவன்", "Vishnu / பெருமாள்", "80s Songs", "90s Songs", "Uncategorized")

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun AppaMusicScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("appa_music", 0) }
    val songs = remember { mutableStateListOf<Song>() }
    val favourites = remember { mutableStateListOf<String>() }
    var currentIndex by remember { mutableIntStateOf(-1) }
    var isPlaying by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("பாடல்களைச் சேர்க்கவும் / Add songs to begin") }
    var player by remember { mutableStateOf<MediaController?>(null) }
    var query by remember { mutableStateOf("") }
    var showFavourites by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("All Songs") }
    var sleepMinutes by remember { mutableIntStateOf(0) }
    var timerRunning by remember { mutableStateOf(false) }
    var pendingSongs by remember { mutableStateOf<List<PendingSong>>(emptyList()) }
    var showImportPreview by remember { mutableStateOf(false) }
    var chosenCategory by remember { mutableStateOf(songCategories.first()) }
    var lastImportedUris by remember { mutableStateOf<List<String>>(emptyList()) }
    var reportText by remember { mutableStateOf("") }
    var importBusy by remember { mutableStateOf(false) }
    var reassignTarget by remember { mutableStateOf<Song?>(null) }
    val categories = remember { mutableStateListOf<String>().apply { addAll(songCategories) } }
    var showCategoryManager by remember { mutableStateOf(false) }
    var newCategoryName by remember { mutableStateOf("") }
    var newPersonName by remember { mutableStateOf("") }
    var personType by remember { mutableStateOf("Music Director") }

    fun saveSongs() {
        val packed = songs.joinToString("\n") { android.util.Base64.encodeToString((it.uri.toString() + "\t" + it.title + "\t" + it.category).toByteArray(), android.util.Base64.NO_WRAP) }
        prefs.edit().putString("songs", packed).apply()
    }
    LaunchedEffect(Unit) {
        prefs.getString("songs", "").orEmpty().lines().filter { it.isNotBlank() }.forEach { row ->
            runCatching {
                val decoded = String(android.util.Base64.decode(row, android.util.Base64.DEFAULT))
                val split = decoded.split("\t", limit = 3)
                val uri = Uri.parse(split[0]); context.contentResolver.openAssetFileDescriptor(uri, "r")?.close()
                songs.add(Song(uri, split.getOrElse(1) { "Audio song" }, split.getOrElse(2) { "Uncategorized" }))
            }
        }
        favourites.addAll(prefs.getStringSet("favourites", emptySet()).orEmpty())
        prefs.getStringSet("custom_categories", emptySet()).orEmpty().sorted().forEach { if (it !in categories) categories.add(it) }
        if (categories.isNotEmpty()) chosenCategory = categories.first()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            val name = runCatching { context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } }.getOrNull() ?: "Audio song"
            if (songs.none { it.uri == uri }) songs.add(Song(uri, name))
        }
        saveSongs()
        status = "${songs.size} பாடல்கள் / songs saved on this phone"
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
        if (treeUri != null) {
            try { context.contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            importBusy = true
            status = "Scanning folder / கோப்புறையைச் சரிபார்க்கிறது…"
            kotlinx.coroutines.MainScope().launch {
                val found = withContext(Dispatchers.IO) { scanAudioFolder(context, treeUri) }
                pendingSongs = found
                chosenCategory = "Uncategorized"
                showImportPreview = true
                importBusy = false
                status = "${found.size} audio files found / கோப்புகள் கண்டறியப்பட்டன"
            }
        }
    }

    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({ runCatching { player = future.get() } }, context.mainExecutor)
        onDispose { MediaController.releaseFuture(future); player = null }
    }
    DisposableEffect(player) {
        val p = player
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { currentIndex = p?.currentMediaItemIndex ?: -1 }
        }
        p?.addListener(listener)
        onDispose { p?.removeListener(listener) }
    }
    LaunchedEffect(timerRunning, sleepMinutes) {
        if (timerRunning && sleepMinutes > 0) { delay(sleepMinutes * 60_000L); player?.pause(); timerRunning = false; status = "Sleep timer finished / நேரம் முடிந்தது" }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF9A3412), secondary = Color(0xFF047857), background = Color(0xFFFFF8EC))) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Text("♫ Appa Music", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF7C2D12))
                Text("அப்பாவுக்கான பாடல்கள் • Songs for Appa", fontSize = 15.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    CategoryButton("80s பாடல்கள்", "1980s", Modifier.weight(1f)) { selectedFilter = "1980s"; showFavourites = false }
                    CategoryButton("90s பாடல்கள்", "1990s", Modifier.weight(1f)) { selectedFilter = "1990s"; showFavourites = false }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    CategoryButton("பக்தி பாடல்கள்", "Devotional", Modifier.weight(1f)) { selectedFilter = "Devotional"; showFavourites = false }
                    Button(onClick = { showFavourites = !showFavourites; selectedFilter = "All Songs" }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Favorite, null); Spacer(Modifier.width(4.dp)); Text(if (showFavourites) "All songs" else "பிடித்தவை / Favourites") }
                }
                // Show user-created categories on the home page automatically.
                val customHomeCategories = categories.filter { it !in songCategories && it != "Uncategorized" }
                customHomeCategories.chunked(2).forEach { categoryRow ->
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        categoryRow.forEach { categoryName ->
                            CategoryButton(categoryName, categoryName, Modifier.weight(1f)) {
                                selectedFilter = categoryName
                                showFavourites = false
                            }
                        }
                        if (categoryRow.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (selectedFilter != "All Songs") {
                    TextButton(onClick = { selectedFilter = "All Songs"; showFavourites = false }) { Text("அனைத்துப் பாடல்களும் / All songs") }
                }
                OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("பாடலைத் தேடுக / Search songs") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { folderPicker.launch(null) }, modifier = Modifier.weight(1f), enabled = !importBusy) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(4.dp)); Text("Folder Import") }
                    OutlinedButton(onClick = { openLegalMusicOptions(context) }, modifier = Modifier.weight(1f)) { Text("இணைய இசை / Online music") }
                }
                OutlinedButton(onClick = { showCategoryManager = true }, modifier = Modifier.fillMaxWidth()) { Text("புதிய பெயர்கள் / பிரிவுகள் • Manage Categories & Names") }
                Text(status, modifier = Modifier.padding(vertical = 6.dp), fontSize = 12.sp, color = Color.DarkGray)
                if (importBusy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                if (reportText.isNotBlank()) {
                    Card(Modifier.fillMaxWidth().padding(bottom = 6.dp)) { Column(Modifier.padding(8.dp)) { Text(reportText); if (lastImportedUris.isNotEmpty()) TextButton(onClick = { songs.removeAll { it.uri.toString() in lastImportedUris }; saveSongs(); lastImportedUris = emptyList(); reportText = "Last batch undone / கடைசி தொகுப்பு நீக்கப்பட்டது" }) { Text("Undo last batch / ரத்து") } } }
                }
                Text(if (showFavourites) "பிடித்த பாடல்கள் / Favourites" else if (selectedFilter == "All Songs") "என் பாடல்கள் / My Songs" else when (selectedFilter) { "1980s" -> "80s பாடல்கள் / 1980s Songs"; "1990s" -> "90s பாடல்கள் / 1990s Songs"; "Devotional" -> "பக்தி பாடல்கள் / Devotional"; else -> selectedFilter }, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                val visibleSongs = songs.withIndex().filter { (_, song) ->
                    val category = song.category.lowercase()
                    val matchesCategory = when (selectedFilter) {
                        "All Songs" -> true
                        "1980s" -> category.contains("1980") || category.contains("80s") || category.contains("1980s")
                        "1990s" -> category.contains("1990") || category.contains("90s") || category.contains("1990s")
                        "Devotional" -> category.contains("devotional") || category.contains("பக்தி") || category.contains("முருகன்") || category.contains("அம்மன்") || category.contains("சிவன்") || category.contains("பெருமாள்") || category.contains("shiva") || category.contains("vishnu") || category.contains("murugan") || category.contains("amman")
                        else -> song.category == selectedFilter
                    }
                    matchesCategory && (!showFavourites || favourites.contains(song.uri.toString())) && song.title.contains(query, ignoreCase = true)
                }
                if (visibleSongs.isEmpty()) {
                    Text("இன்னும் பாடல்கள் இல்லை.\nNo songs yet. Import audio files or use Online music to open authorized music services. Streaming-service downloads usually stay inside their own app.", modifier = Modifier.padding(top = 12.dp), fontSize = 14.sp, lineHeight = 21.sp)
                } else {
                    LazyColumn(Modifier.weight(1f)) {
                        items(visibleSongs, key = { it.value.uri.toString() }) { indexed ->
                            val index = indexed.index; val song = indexed.value
                            Row(Modifier.fillMaxWidth().clickable { playSong(index, songs, player) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayArrow, null, tint = Color(0xFF9A3412))
                                Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                                    Text(song.title, fontWeight = if (index == currentIndex) FontWeight.Bold else FontWeight.Normal, maxLines = 2)
                                    Text(song.category, fontSize = 12.sp, color = Color.Gray)
                                    TextButton(onClick = { reassignTarget = song }) { Text("Change category / பிரிவு மாற்று", fontSize = 10.sp) }
                                }
                                IconButton(onClick = {
                                    val key = song.uri.toString()
                                    if (favourites.contains(key)) favourites.remove(key) else favourites.add(key)
                                    prefs.edit().putStringSet("favourites", favourites.toSet()).apply()
                                }) { Icon(if (favourites.contains(song.uri.toString())) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "Favourite") }
                            }
                            HorizontalDivider()
                        }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE8B4)), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(if (currentIndex in songs.indices) songs[currentIndex].title else "இப்போது பாடல் இல்லை / Nothing playing", fontWeight = FontWeight.Bold, maxLines = 2)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                            IconButton(onClick = { if (songs.isNotEmpty()) playSong((currentIndex - 1 + songs.size) % songs.size, songs, player) }) { Icon(Icons.Default.SkipPrevious, "Previous") }
                            IconButton(onClick = { val p = player; if (p != null) { if (p.isPlaying) p.pause() else if (p.mediaItemCount > 0) p.play() else if (songs.isNotEmpty()) playSong(0, songs, p) } }) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", modifier = Modifier.size(38.dp)) }
                            IconButton(onClick = { if (songs.isNotEmpty()) playSong((currentIndex + 1) % songs.size, songs, player) }) { Icon(Icons.Default.SkipNext, "Next") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Sleep timer / உறக்க நேரம்", fontSize = 12.sp)
                            var expanded by remember { mutableStateOf(false) }
                            Box {
                                TextButton(onClick = { expanded = true }) { Text(if (timerRunning) "$sleepMinutes min ✓" else if (sleepMinutes == 0) "Off / நிறுத்தம்" else "$sleepMinutes min") }
                                DropdownMenu(expanded, { expanded = false }) {
                                    listOf(0, 15, 30, 60).forEach { minutes -> DropdownMenuItem(text = { Text(if (minutes == 0) "Off / நிறுத்தம்" else "$minutes minutes") }, onClick = { sleepMinutes = minutes; timerRunning = minutes > 0; expanded = false }) }
                                }
                            }
                        }
                    }
                }
                Text("Offline after songs are saved • பாடல்கள் சேமித்த பின் இணையம் தேவையில்லை", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }

    if (showCategoryManager) {
        AlertDialog(
            onDismissRequest = { showCategoryManager = false },
            title = { Text("Manage Categories & Names / பெயர்கள் மற்றும் பிரிவுகள்") },
            text = {
                Column(Modifier.heightIn(max = 520.dp)) {
                    Text("1. Add a new category / புதிய பிரிவு", fontWeight = FontWeight.Bold)
                    OutlinedTextField(newCategoryName, { newCategoryName = it }, label = { Text("Category name / பிரிவு பெயர்") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        val value = newCategoryName.trim()
                        if (value.isNotEmpty() && categories.none { it.equals(value, true) }) {
                            categories.add(value); prefs.edit().putStringSet("custom_categories", categories.filter { it !in songCategories }.toSet()).apply()
                            chosenCategory = value; newCategoryName = ""
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Add category / பிரிவு சேர்க்க") }
                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider()
                    Text("2. Add a Music Director / Actor / Singer / Deity name", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    var typeExpanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { typeExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(personType) }
                        DropdownMenu(expanded = typeExpanded, onDismissRequest = { typeExpanded = false }) {
                            listOf("Music Director", "Actor", "Singer", "Movie", "Devotional Deity", "Year / Decade").forEach { type ->
                                DropdownMenuItem(text = { Text(type) }, onClick = { personType = type; typeExpanded = false })
                            }
                        }
                    }
                    OutlinedTextField(newPersonName, { newPersonName = it }, label = { Text("Type a new name / புதிய பெயர்") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        val value = newPersonName.trim()
                        val category = "$personType: $value"
                        if (value.isNotEmpty() && categories.none { it.equals(category, true) }) {
                            categories.add(category); prefs.edit().putStringSet("custom_categories", categories.filter { it !in songCategories }.toSet()).apply()
                            chosenCategory = category; newPersonName = ""
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Save name / பெயரைச் சேமி") }
                    Spacer(Modifier.height(10.dp))
                    Text("Saved categories (${categories.size})", fontWeight = FontWeight.Bold)
                    LazyColumn(Modifier.heightIn(max = 160.dp)) {
                        items(categories.toList()) { cat ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text(cat, modifier = Modifier.weight(1f), fontSize = 13.sp)
                                if (cat !in songCategories) TextButton(onClick = {
                                    categories.remove(cat)
                                    prefs.edit().putStringSet("custom_categories", categories.filter { it !in songCategories }.toSet()).apply()
                                    songs.indices.forEach { i -> if (songs[i].category == cat) songs[i] = songs[i].copy(category = "Uncategorized") }
                                    saveSongs()
                                    if (chosenCategory == cat) chosenCategory = categories.firstOrNull() ?: "Uncategorized"
                                }) { Text("Delete") }
                            }
                        }
                    }
                    Text("Names are saved on this phone and can be selected as a song category during import. Deleting a category moves its songs to Uncategorized.", fontSize = 11.sp, color = Color.Gray)
                }
            },
            confirmButton = { TextButton(onClick = { showCategoryManager = false }) { Text("Done / முடிந்தது") } }
        )
    }

    if (showImportPreview) {
        AlertDialog(onDismissRequest = { showImportPreview = false },
            title = { Text("Import preview / முன்பார்வை") },
            text = {
                Column(Modifier.heightIn(max = 420.dp)) {
                    Text("${pendingSongs.size} audio files. Choose a category for this folder batch:")
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(chosenCategory) }
                        DropdownMenu(expanded, { expanded = false }, modifier = Modifier.heightIn(max = 300.dp)) {
                            categories.forEach { cat -> DropdownMenuItem(text = { Text(cat) }, onClick = { chosenCategory = cat; expanded = false }) }
                        }
                    }
                    Text("Preview: first 25 files", fontWeight = FontWeight.Bold)
                    LazyColumn(Modifier.heightIn(max = 230.dp)) { items(pendingSongs.take(25), key = { it.uri.toString() }) { Text("• ${it.title}", modifier = Modifier.padding(3.dp), fontSize = 13.sp) } }
                    if (pendingSongs.size > 25) Text("and ${pendingSongs.size - 25} more…")
                    Text("Duplicates are skipped by URI or file name.", fontSize = 12.sp, color = Color.Gray)
                }
            },
            confirmButton = { TextButton(onClick = {
                var duplicateCount = 0; var addedCount = 0
                val seenUris = songs.map { it.uri.toString() }.toMutableSet()
                val seenNames = songs.map { it.title.lowercase() }.toMutableSet()
                val batch = mutableListOf<String>()
                pendingSongs.forEach { item ->
                    if (item.uri.toString() in seenUris || item.title.lowercase() in seenNames) duplicateCount++
                    else { songs.add(Song(item.uri, item.title, chosenCategory)); seenUris.add(item.uri.toString()); seenNames.add(item.title.lowercase()); batch.add(item.uri.toString()); addedCount++ }
                }
                lastImportedUris = batch; saveSongs()
                reportText = "Import report: $addedCount added • $duplicateCount duplicates skipped • Category: $chosenCategory"
                status = "Import complete / இறக்குமதி முடிந்தது"
                pendingSongs = emptyList(); showImportPreview = false
            }) { Text("Import all / அனைத்தையும் சேர்க்க") } },
            dismissButton = { TextButton(onClick = { showImportPreview = false; pendingSongs = emptyList() }) { Text("Cancel / ரத்து") } }
        )
    }
    reassignTarget?.let { target ->
        var newCat by remember(target.uri) { mutableStateOf(target.category) }
        var expanded by remember { mutableStateOf(false) }
        AlertDialog(onDismissRequest = { reassignTarget = null }, title = { Text("Change category / பிரிவு மாற்று") },
            text = { Column { Text(target.title); Box { OutlinedButton(onClick = { expanded = true }) { Text(newCat) }; DropdownMenu(expanded, { expanded = false }) { categories.forEach { cat -> DropdownMenuItem(text = { Text(cat) }, onClick = { newCat = cat; expanded = false }) } } } } },
            confirmButton = { TextButton(onClick = { val i = songs.indexOfFirst { it.uri == target.uri }; if (i >= 0) songs[i] = songs[i].copy(category = newCat); saveSongs(); reassignTarget = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { reassignTarget = null }) { Text("Cancel") } })
    }

}


private suspend fun scanAudioFolder(context: android.content.Context, treeUri: Uri): List<PendingSong> {
    val out = mutableListOf<PendingSong>()
    val stack = ArrayDeque<Uri>()
    val rootId = DocumentsContract.getTreeDocumentId(treeUri)
    stack.add(DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId))
    val seen = mutableSetOf<String>()
    while (stack.isNotEmpty()) {
        val dir = stack.removeLast()
        if (!seen.add(dir.toString())) continue
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, DocumentsContract.getDocumentId(dir))
        try {
            context.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                while (c.moveToNext()) {
                    val id = c.getString(idCol); val name = c.getString(nameCol) ?: "Audio song"; val mime = c.getString(mimeCol).orEmpty()
                    val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) stack.add(uri)
                    else if (mime.startsWith("audio/") || name.substringAfterLast('.', "").lowercase() in setOf("mp3", "m4a", "aac", "wav", "ogg", "flac", "opus")) out.add(PendingSong(uri, name))
                }
            }
        } catch (_: Exception) { }
    }
    return out.distinctBy { it.uri.toString() }.sortedBy { it.title.lowercase() }
}

@Composable
private fun CategoryButton(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.height(66.dp).clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = when (subtitle) { "1980s" -> Color(0xFFFECACA); "1990s" -> Color(0xFFBFDBFE); "Devotional" -> Color(0xFFA7F3D0); else -> Color(0xFFFDE68A) })) {
        Column(Modifier.fillMaxSize().padding(8.dp), verticalArrangement = Arrangement.Center) { Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(subtitle, fontSize = 11.sp, color = Color.DarkGray) }
    }
}

private fun playSong(index: Int, songs: List<Song>, player: MediaController?) {
    if (index !in songs.indices || player == null) return
    val items = songs.map { song -> MediaItem.Builder().setUri(song.uri).setMediaId(song.uri.toString()).setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(song.title).build()).build() }
    player.setMediaItems(items, index, 0L); player.prepare(); player.play()
}

private fun openLegalMusicOptions(context: android.content.Context) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=official+Tamil+music+download+legally+MP3+public+domain"))
    runCatching { context.startActivity(intent) }
}
